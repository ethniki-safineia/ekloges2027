
const votes = {
    kasidiaris: 0,
    mitsotakis: 0,
    konstantopoulou: 0,
    latinopoulou: 0
};

function vote(candidate) {
    if (localStorage.getItem("hasVoted")) {
        alert("Έχετε ήδη ψηφίσει!");
        return;
    }
    votes[candidate]++;
    localStorage.setItem("hasVoted", "true");
    updateChart();
}

const ctx = document.getElementById("resultsChart").getContext("2d");
const chart = new Chart(ctx, {
    type: "bar",
    data: {
        labels: ["Κασιδιάρης", "Μητσοτάκης", "Κωνσταντοπούλου", "Λατινοπούλου"],
        datasets: [{
            label: "Ψήφοι",
            data: Object.values(votes),
            backgroundColor: ["red", "blue", "green", "purple"]
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

function updateChart() {
    chart.data.datasets[0].data = Object.values(votes);
    chart.update();
}
